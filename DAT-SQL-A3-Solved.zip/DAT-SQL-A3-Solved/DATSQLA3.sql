-- DevishaArunadeviTiwari solved SQL-Assignment-03
-- Task 1: Create a stored procedure to display the restaurant name, type and cuisine where the table booking is not zero
CREATE PROCEDURE dbo.sp_RestaurantsWithTableBooking
AS
BEGIN
    SELECT RestaurantName, RestaurantType, Cuisine
    FROM Restaurants
    WHERE TableBooking > 0;
END;
GO

-- Task 2: Create a transaction and update the cuisine type 'Cafe' to 'Cafeteria'. Check the result and rollback it.
BEGIN TRY
    BEGIN TRANSACTION;

    UPDATE Restaurants
    SET Cuisine = 'Cafeteria'
    WHERE Cuisine = 'Cafe';

    COMMIT TRANSACTION;

    SELECT 'Update successful' AS Result;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;

    SELECT ERROR_MESSAGE() AS ErrorMessage;
END CATCH;
GO

-- Task 3: Generate a row number column and find the top 5 areas with the highest rating of restaurants
WITH RankedRestaurants AS (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY Area ORDER BY Rating DESC) AS RowNum
    FROM Restaurants
)
SELECT Area, RestaurantName, Rating
FROM RankedRestaurants
WHERE RowNum <= 5;
GO

-- Task 4: Use the while loop to display the numbers 1 to 50
DECLARE @i INT = 1;
WHILE @i <= 50
BEGIN
    PRINT @i;
    SET @i = @i + 1;
END;
GO

-- Task 5: Write a query to Create a TopRating view to store the generated top 5 highest rating of restaurants
CREATE VIEW TopRating
AS
WITH RankedRestaurants AS (
    SELECT *,
           ROW_NUMBER() OVER (ORDER BY Rating DESC) AS RowNum
    FROM Restaurants
)
SELECT RestaurantName, Rating
FROM RankedRestaurants
WHERE RowNum <= 5;
GO

-- Task 6: Write a trigger that sends an email notification to the restaurant owner whenever a new record is inserted
CREATE TRIGGER trg_SendEmailOnInsert
ON Restaurants
AFTER INSERT
AS
BEGIN
    DECLARE @RestaurantName VARCHAR(100);
    DECLARE @OwnerEmail VARCHAR(100);
    DECLARE @Subject NVARCHAR(1000);
    DECLARE @Body NVARCHAR(MAX);

    SELECT @RestaurantName = i.RestaurantName, @OwnerEmail = i.OwnerEmail
    FROM inserted i;

    SET @Subject = 'New Record Inserted for Your Restaurant: ' + @RestaurantName;
    SET @Body = 'Dear Restaurant Owner, a new record has been inserted for your restaurant: ' + @RestaurantName + '.';

    -- Replace with actual email sending code or procedure call
    -- Example: EXEC sp_send_dbmail @recipients = @OwnerEmail, @subject = @Subject, @body = @Body;

    PRINT 'Email notification sent.';
END;
GO