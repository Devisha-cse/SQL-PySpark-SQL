--DevishaArunadeviTiwari Solved SQL-Assignment-02
-- Task 1: Create a user-defined function to stuff 'Chicken' into 'Quick Bites'
CREATE FUNCTION dbo.fn_StuffChickenIntoQuickBites(@originalCuisine VARCHAR(100))
RETURNS VARCHAR(100)
AS
BEGIN
    DECLARE @result VARCHAR(100);
    SET @result = REPLACE(@originalCuisine, 'Chicken', 'Quick Chicken Bites');
    RETURN @result;
END;
GO

-- Task 2: Use the function to display the restaurant name and cuisine type which has the maximum number of rating
SELECT TOP 1
    RestaurantName,
    dbo.fn_StuffChickenIntoQuickBites(Cuisine) AS CuisineWithChicken
FROM
    Restaurants
WHERE
    Rating = (SELECT MAX(Rating) FROM Restaurants);
GO

-- Task 3: Create a Rating Status column
ALTER TABLE Restaurants
ADD RatingStatus VARCHAR(20);

UPDATE Restaurants
SET RatingStatus = CASE
                     WHEN Rating > 4 THEN 'Excellent'
                     WHEN Rating > 3.5 THEN 'Good'
                     WHEN Rating > 3 THEN 'Average'
                     ELSE 'Bad'
                  END;
GO

-- Task 4: Find the Ceil, floor and absolute values of the rating column and display the current date, year, month_name and day
SELECT
    Rating,
    CEILING(Rating) AS CeilValue,
    FLOOR(Rating) AS FloorValue,
    ABS(Rating) AS AbsoluteValue,
    GETDATE() AS CurrentDate,
    FORMAT(GETDATE(), 'yyyy') AS [Year],
    FORMAT(GETDATE(), 'MMMM') AS [Month_Name],
    FORMAT(GETDATE(), 'dd') AS [Day];
GO

-- Task 5: Display the restaurant type and total average cost using rollup
SELECT
    RestaurantType,
    ROLLUP(AVG(TotalCost)) AS TotalAverageCost
FROM
    Restaurants
GROUP BY
    RestaurantType;
GO